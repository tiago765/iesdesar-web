// Pase de fotos da portada: cambia soa cada 5 segundos, con puntos e frechas.
document.querySelectorAll('.diapositivas').forEach(function (caixa) {
	var fotos = Array.prototype.slice.call(caixa.querySelectorAll('.diapositiva'));
	if (fotos.length < 2) return;

	var actual = 0;
	var temporizador = null;
	var semMovemento = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

	var puntos = document.createElement('div');
	puntos.className = 'diapositivas__puntos';
	fotos.forEach(function (f, i) {
		var b = document.createElement('button');
		b.type = 'button';
		b.setAttribute('aria-label', 'Foto ' + (i + 1));
		b.addEventListener('click', function () { amosar(i); reiniciar(); });
		puntos.appendChild(b);
	});

	function frecha(clase, texto, etiqueta, paso) {
		var b = document.createElement('button');
		b.type = 'button';
		b.className = 'diapositivas__frecha ' + clase;
		b.setAttribute('aria-label', etiqueta);
		b.textContent = texto;
		b.addEventListener('click', function () { amosar(actual + paso); reiniciar(); });
		return b;
	}

	caixa.appendChild(frecha('diapositivas__frecha--anterior', '‹', 'Foto anterior', -1));
	caixa.appendChild(frecha('diapositivas__frecha--seguinte', '›', 'Foto seguinte', 1));
	caixa.appendChild(puntos);

	function amosar(n) {
		actual = (n + fotos.length) % fotos.length;
		fotos.forEach(function (f, i) { f.classList.toggle('activa', i === actual); });
		Array.prototype.forEach.call(puntos.children, function (b, i) {
			b.classList.toggle('activo', i === actual);
			b.setAttribute('aria-current', i === actual ? 'true' : 'false');
		});
	}
	function arrancar() {
		if (semMovemento || temporizador) return;
		temporizador = setInterval(function () { amosar(actual + 1); }, 5000);
	}
	function parar() {
		clearInterval(temporizador);
		temporizador = null;
	}
	function reiniciar() { parar(); arrancar(); }

	caixa.addEventListener('mouseenter', parar);
	caixa.addEventListener('mouseleave', arrancar);
	caixa.addEventListener('focusin', parar);
	caixa.addEventListener('focusout', arrancar);

	caixa.classList.add('lista');
	amosar(0);
	arrancar();
});
