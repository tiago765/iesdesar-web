// Carrusel de noticias: engade botóns anterior/seguinte á lista de novas.
document.querySelectorAll('.carrusel').forEach(function (carrusel) {
	var lista = carrusel.querySelector('.wp-block-post-template');
	if (!lista || lista.children.length < 2) return;

	var botons = document.createElement('div');
	botons.className = 'carrusel__botons';
	botons.innerHTML =
		'<button type="button" class="carrusel__boton" aria-label="Noticias anteriores">←</button>' +
		'<button type="button" class="carrusel__boton" aria-label="Noticias seguintes">→</button>';
	carrusel.appendChild(botons);

	var anterior = botons.children[0];
	var seguinte = botons.children[1];

	function paso() {
		return lista.children[0].getBoundingClientRect().width + 20;
	}
	function actualizar() {
		anterior.disabled = lista.scrollLeft <= 2;
		seguinte.disabled = lista.scrollLeft + lista.clientWidth >= lista.scrollWidth - 2;
	}

	anterior.addEventListener('click', function () { lista.scrollBy({ left: -paso() }); });
	seguinte.addEventListener('click', function () { lista.scrollBy({ left: paso() }); });
	lista.addEventListener('scroll', actualizar, { passive: true });
	window.addEventListener('resize', actualizar);
	actualizar();
});
