<?php
/**
 * Title: Pé de páxina
 * Slug: iesdesar/pe
 * Categories: iesdesar
 * Inserter: false
 */
?>
<!-- wp:group {"tagName":"footer","className":"pe","layout":{"type":"default"}} -->
<footer class="wp-block-group pe"><!-- wp:group {"className":"pe__fila","layout":{"type":"default"}} -->
<div class="wp-block-group pe__fila"><!-- wp:group {"className":"pe__centro","layout":{"type":"default"}} -->
<div class="wp-block-group pe__centro"><!-- wp:image {"sizeSlug":"full","className":"pe__logo-centro"} -->
<figure class="wp-block-image size-full pe__logo-centro"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/logo-ies-de-sar.png' ) ); ?>" alt="IES de Sar"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"pe__nome"} -->
<p class="pe__nome"><strong>IES DE SAR</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"pe__enderezo"} -->
<p class="pe__enderezo">Rúa Bernardo Barreiro de Vázquez Varela, s/n<br>15702 - Santiago de Compostela (A Coruña)<br><a href="tel:+34881867162">881 867 162</a><br><a href="mailto:ies.sar@edu.xunta.gal">ies.sar@edu.xunta.gal</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"pe__dereita","layout":{"type":"default"}} -->
<div class="wp-block-group pe__dereita"><!-- wp:group {"className":"pe__logos","layout":{"type":"default"}} -->
<div class="wp-block-group pe__logos"><!-- wp:image {"sizeSlug":"full","className":"pe__logo"} -->
<figure class="wp-block-image size-full pe__logo"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/punto-laranxa.png' ) ); ?>" alt="Punto Laranxa"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","className":"pe__logo"} -->
<figure class="wp-block-image size-full pe__logo"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/proa.png' ) ); ?>" alt="Programa PROA+"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","className":"pe__logo"} -->
<figure class="wp-block-image size-full pe__logo"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/cofinanciado-ue.png' ) ); ?>" alt="Cofinanciado pola Unión Europea"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"pe__legal"} -->
<p class="pe__legal"><a href="/aviso-legal/">Aviso Legal</a><a href="/politica-de-cookies/">Política de cookies</a><a href="/politica-de-privacidade/">Política de privacidade</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></footer>
<!-- /wp:group -->
