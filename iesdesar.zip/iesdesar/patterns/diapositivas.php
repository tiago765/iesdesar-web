<?php
/**
 * Title: Pase de fotos do centro
 * Slug: iesdesar/diapositivas
 * Categories: iesdesar
 * Description: Fotos do instituto que van pasando soas. Para cambiar unha foto, selecciónaa e preme "Substituír".
 */
?>
<!-- wp:group {"className":"diapositivas","layout":{"type":"default"}} -->
<div class="wp-block-group diapositivas">
<!-- wp:image {"sizeSlug":"full","className":"diapositiva"} -->
<figure class="wp-block-image size-full diapositiva"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/diapositivas/01-edificio.jpg' ) ); ?>" alt="O IES de Sar"/><figcaption class="wp-element-caption">O IES de Sar</figcaption></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","className":"diapositiva"} -->
<figure class="wp-block-image size-full diapositiva"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/diapositivas/02-mural.jpg' ) ); ?>" alt="30 anos sementando soños"/><figcaption class="wp-element-caption">30 anos sementando soños</figcaption></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","className":"diapositiva"} -->
<figure class="wp-block-image size-full diapositiva"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/diapositivas/03-biblioteca.jpg' ) ); ?>" alt="A biblioteca"/><figcaption class="wp-element-caption">A biblioteca</figcaption></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","className":"diapositiva"} -->
<figure class="wp-block-image size-full diapositiva"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/diapositivas/04-caaveiro.jpg' ) ); ?>" alt="Saída a Caaveiro"/><figcaption class="wp-element-caption">Saída a Caaveiro</figcaption></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","className":"diapositiva"} -->
<figure class="wp-block-image size-full diapositiva"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/diapositivas/05-aula.jpg' ) ); ?>" alt="Matemáticas e artes"/><figcaption class="wp-element-caption">Matemáticas e artes</figcaption></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","className":"diapositiva"} -->
<figure class="wp-block-image size-full diapositiva"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/diapositivas/06-rio.jpg' ) ); ?>" alt="Proxecto Ríos"/><figcaption class="wp-element-caption">Proxecto Ríos</figcaption></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","className":"diapositiva"} -->
<figure class="wp-block-image size-full diapositiva"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/diapositivas/07-saida.jpg' ) ); ?>" alt="Excursións"/><figcaption class="wp-element-caption">Excursións</figcaption></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","className":"diapositiva"} -->
<figure class="wp-block-image size-full diapositiva"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/diapositivas/08-laboratorio.jpg' ) ); ?>" alt="No laboratorio"/><figcaption class="wp-element-caption">No laboratorio</figcaption></figure>
<!-- /wp:image -->

</div>
<!-- /wp:group -->
