<?php
/**
 * Title: Banner destacado
 * Slug: iesdesar/banner
 * Categories: iesdesar
 * Description: Aviso grande da portada (admisión, matrícula...).
 */
?>
<!-- wp:group {"className":"banner","layout":{"type":"default"}} -->
<div class="wp-block-group banner"><!-- wp:group {"className":"banner__texto","layout":{"type":"default"}} -->
<div class="wp-block-group banner__texto"><!-- wp:heading {"level":2,"className":"banner__titulo"} -->
<h2 class="wp-block-heading banner__titulo">Admisión FP<br>2025-2026</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"banner__entrada"} -->
<p class="banner__entrada">Aberto o prazo de presentación de solicitudes desde o 16 de xuño ás 9:00 ao 2 de xullo ás 13:00 horas.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/fp/">Máis información</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->

<!-- wp:image {"sizeSlug":"full","className":"banner__imaxe"} -->
<figure class="wp-block-image size-full banner__imaxe"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/fp.svg' ) ); ?>" alt="Formación Profesional"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group -->
