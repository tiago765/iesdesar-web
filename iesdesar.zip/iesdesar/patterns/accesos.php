<?php
/**
 * Title: Accesos rápidos
 * Slug: iesdesar/accesos
 * Categories: iesdesar
 * Description: Fila de botóns con icona (Aula, Transporte, ANPA, Libros).
 */
?>
<!-- wp:group {"className":"accesos","layout":{"type":"default"}} -->
<div class="wp-block-group accesos">
<!-- wp:group {"className":"icona-ligazon","layout":{"type":"default"}} -->
<div class="wp-block-group icona-ligazon"><!-- wp:image {"sizeSlug":"full","className":"icona-ligazon__img"} -->
<figure class="wp-block-image size-full icona-ligazon__img"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/aula.svg' ) ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"icona-ligazon__texto"} -->
<p class="icona-ligazon__texto"><a href="http://centros.edu.xunta.gal/iesdesar/aulavirtual">AULA</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"icona-ligazon","layout":{"type":"default"}} -->
<div class="wp-block-group icona-ligazon"><!-- wp:image {"sizeSlug":"full","className":"icona-ligazon__img"} -->
<figure class="wp-block-image size-full icona-ligazon__img"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/transporte.svg' ) ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"icona-ligazon__texto"} -->
<p class="icona-ligazon__texto"><a href="/transporte/">Transporte</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"icona-ligazon","layout":{"type":"default"}} -->
<div class="wp-block-group icona-ligazon"><!-- wp:image {"sizeSlug":"full","className":"icona-ligazon__img"} -->
<figure class="wp-block-image size-full icona-ligazon__img"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/anpa.svg' ) ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"icona-ligazon__texto"} -->
<p class="icona-ligazon__texto"><a href="/anpa/">ANPA</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"icona-ligazon","layout":{"type":"default"}} -->
<div class="wp-block-group icona-ligazon"><!-- wp:image {"sizeSlug":"full","className":"icona-ligazon__img"} -->
<figure class="wp-block-image size-full icona-ligazon__img"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/libros.svg' ) ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"icona-ligazon__texto"} -->
<p class="icona-ligazon__texto"><a href="/libros-por-curso/">Libros</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

</div>
<!-- /wp:group -->
