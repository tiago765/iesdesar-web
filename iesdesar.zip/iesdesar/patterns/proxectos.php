<?php
/**
 * Title: Proxectos do centro
 * Slug: iesdesar/proxectos
 * Categories: iesdesar
 * Description: Grella de iconas cos proxectos e actividades.
 */
?>
<!-- wp:group {"className":"proxectos","layout":{"type":"default"}} -->
<div class="wp-block-group proxectos">
<!-- wp:group {"className":"icona-ligazon","layout":{"type":"default"}} -->
<div class="wp-block-group icona-ligazon"><!-- wp:image {"sizeSlug":"full","className":"icona-ligazon__img"} -->
<figure class="wp-block-image size-full icona-ligazon__img"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/rios.svg' ) ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"icona-ligazon__texto"} -->
<p class="icona-ligazon__texto"><a href="/proxecto-rios/">Proxecto Ríos</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"icona-ligazon","layout":{"type":"default"}} -->
<div class="wp-block-group icona-ligazon"><!-- wp:image {"sizeSlug":"full","className":"icona-ligazon__img"} -->
<figure class="wp-block-image size-full icona-ligazon__img"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/lectura.svg' ) ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"icona-ligazon__texto"} -->
<p class="icona-ligazon__texto"><a href="/club-lectura/">Club Lectura</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"icona-ligazon","layout":{"type":"default"}} -->
<div class="wp-block-group icona-ligazon"><!-- wp:image {"sizeSlug":"full","className":"icona-ligazon__img"} -->
<figure class="wp-block-image size-full icona-ligazon__img"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/erasmus.svg' ) ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"icona-ligazon__texto"} -->
<p class="icona-ligazon__texto"><a href="/erasmus/">Erasmus</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"icona-ligazon","layout":{"type":"default"}} -->
<div class="wp-block-group icona-ligazon"><!-- wp:image {"sizeSlug":"full","className":"icona-ligazon__img"} -->
<figure class="wp-block-image size-full icona-ligazon__img"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/biblioteca.svg' ) ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"icona-ligazon__texto"} -->
<p class="icona-ligazon__texto"><a href="/biblioteca/">Biblioteca</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"icona-ligazon","layout":{"type":"default"}} -->
<div class="wp-block-group icona-ligazon"><!-- wp:image {"sizeSlug":"full","className":"icona-ligazon__img"} -->
<figure class="wp-block-image size-full icona-ligazon__img"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/patrimonio.svg' ) ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"icona-ligazon__texto"} -->
<p class="icona-ligazon__texto"><a href="/patrimonio/">Patrimonio</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"icona-ligazon","layout":{"type":"default"}} -->
<div class="wp-block-group icona-ligazon"><!-- wp:image {"sizeSlug":"full","className":"icona-ligazon__img"} -->
<figure class="wp-block-image size-full icona-ligazon__img"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/non-beber.svg' ) ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"icona-ligazon__texto"} -->
<p class="icona-ligazon__texto"><a href="/non-beber/">Non beber</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"icona-ligazon","layout":{"type":"default"}} -->
<div class="wp-block-group icona-ligazon"><!-- wp:image {"sizeSlug":"full","className":"icona-ligazon__img"} -->
<figure class="wp-block-image size-full icona-ligazon__img"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/excursions.svg' ) ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"icona-ligazon__texto"} -->
<p class="icona-ligazon__texto"><a href="/excursions/">Excursións fin de curso</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"icona-ligazon","layout":{"type":"default"}} -->
<div class="wp-block-group icona-ligazon"><!-- wp:image {"sizeSlug":"full","className":"icona-ligazon__img"} -->
<figure class="wp-block-image size-full icona-ligazon__img"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/pie.svg' ) ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"icona-ligazon__texto"} -->
<p class="icona-ligazon__texto"><a href="/pie/">PIE</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"icona-ligazon","layout":{"type":"default"}} -->
<div class="wp-block-group icona-ligazon"><!-- wp:image {"sizeSlug":"full","className":"icona-ligazon__img"} -->
<figure class="wp-block-image size-full icona-ligazon__img"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/icons/arte.svg' ) ); ?>" alt=""/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"icona-ligazon__texto"} -->
<p class="icona-ligazon__texto"><a href="/semanas-de-arte/">Semanas de arte</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

</div>
<!-- /wp:group -->
