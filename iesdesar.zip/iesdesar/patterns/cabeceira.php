<?php
/**
 * Title: Cabeceira
 * Slug: iesdesar/cabeceira
 * Categories: iesdesar
 * Inserter: false
 */
?>
<!-- wp:group {"tagName":"header","className":"cabeceira","layout":{"type":"default"}} -->
<header class="wp-block-group cabeceira"><!-- wp:group {"className":"cabeceira__fila","layout":{"type":"default"}} -->
<div class="wp-block-group cabeceira__fila"><!-- wp:group {"className":"cabeceira__contacto","layout":{"type":"default"}} -->
<div class="wp-block-group cabeceira__contacto"><!-- wp:paragraph {"className":"tel"} -->
<p class="tel"><a href="tel:+34881867162">881 867 162</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"correo"} -->
<p class="correo"><a href="mailto:ies.sar@edu.xunta.gal">ies.sar@edu.xunta.gal</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"custom","className":"cabeceira__logo"} -->
<figure class="wp-block-image size-full cabeceira__logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/logo-ies-de-sar.png' ) ); ?>" alt="IES de Sar, Santiago de Compostela"/></a></figure>
<!-- /wp:image -->

<!-- wp:social-links {"iconColor":"negro","iconColorValue":"#1d1d1b","className":"is-style-logos-only cabeceira__redes"} -->
<ul class="wp-block-social-links has-icon-color is-style-logos-only cabeceira__redes"><!-- wp:social-link {"url":"#","service":"x"} /-->

<!-- wp:social-link {"url":"#","service":"facebook"} /-->

<!-- wp:social-link {"url":"https://www.instagram.com/ies.desar/","service":"instagram"} /--></ul>
<!-- /wp:social-links --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"menu-barra","layout":{"type":"default"}} -->
<div class="wp-block-group menu-barra"><!-- wp:navigation {"overlayMenu":"mobile","className":"menu-principal","layout":{"type":"flex","justifyContent":"left"}} -->
<!-- wp:navigation-submenu {"label":"COLEXIO","url":"/ola/","kind":"custom"} -->
<!-- wp:navigation-link {"label":"Ola!!!","url":"/ola/","kind":"custom"} /-->
<!-- wp:navigation-link {"label":"Horario","url":"/horario/","kind":"custom"} /-->
<!-- wp:navigation-link {"label":"Documentos","url":"/documentos/","kind":"custom"} /-->
<!-- wp:navigation-link {"label":"Transporte","url":"/transporte/","kind":"custom"} /-->
<!-- /wp:navigation-submenu -->
<!-- wp:navigation-submenu {"label":"ADMINISTRACIÓN","url":"/matricula/","kind":"custom"} -->
<!-- wp:navigation-link {"label":"Libros por curso","url":"/libros-por-curso/","kind":"custom"} /-->
<!-- wp:navigation-link {"label":"Matrícula","url":"/matricula/","kind":"custom"} /-->
<!-- wp:navigation-link {"label":"Fondo de libros","url":"/fondo-de-libros/","kind":"custom"} /-->
<!-- wp:navigation-link {"label":"Solicitude de transporte","url":"/solicitude-transporte/","kind":"custom"} /-->
<!-- wp:navigation-link {"label":"PAU","url":"/pau/","kind":"custom"} /-->
<!-- wp:navigation-link {"label":"Outros impresos","url":"/outros-impresos/","kind":"custom"} /-->
<!-- /wp:navigation-submenu -->
<!-- wp:navigation-submenu {"label":"ENSINANZAS","url":"/eso/","kind":"custom"} -->
<!-- wp:navigation-submenu {"label":"ESO","url":"/eso/","kind":"custom"} -->
<!-- wp:navigation-link {"label":"1º ESO","url":"/eso/1-eso/","kind":"custom"} /-->
<!-- wp:navigation-link {"label":"2º ESO","url":"/eso/2-eso/","kind":"custom"} /-->
<!-- wp:navigation-link {"label":"3º ESO","url":"/eso/3-eso/","kind":"custom"} /-->
<!-- wp:navigation-link {"label":"4º ESO","url":"/eso/4-eso/","kind":"custom"} /-->
<!-- /wp:navigation-submenu -->
<!-- wp:navigation-submenu {"label":"Bacharelato","url":"/bacharelato/","kind":"custom"} -->
<!-- wp:navigation-link {"label":"Artes","url":"/bacharelato/artes/","kind":"custom"} /-->
<!-- wp:navigation-link {"label":"Ciencias e Tecnoloxía","url":"/bacharelato/ciencias/","kind":"custom"} /-->
<!-- wp:navigation-link {"label":"Humanidades e Ciencias Sociais","url":"/bacharelato/humanidades-ciencias-sociais/","kind":"custom"} /-->
<!-- /wp:navigation-submenu -->
<!-- /wp:navigation-submenu -->
<!-- /wp:navigation --></div>
<!-- /wp:group --></header>
<!-- /wp:group -->
