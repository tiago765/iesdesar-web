<?php
/**
 * Tema IES de Sar.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'wp_enqueue_scripts', function () {
	$v = wp_get_theme()->get( 'Version' );
	wp_enqueue_style( 'iesdesar', get_theme_file_uri( 'assets/css/tema.css' ), array(), $v );
	wp_enqueue_script( 'iesdesar-carrusel', get_theme_file_uri( 'assets/js/carrusel.js' ), array(), $v, true );
} );

add_action( 'after_setup_theme', function () {
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/css/tema.css' );
	add_theme_support( 'post-thumbnails' );
} );

add_action( 'init', function () {
	register_block_pattern_category( 'iesdesar', array( 'label' => 'IES de Sar' ) );
} );

add_filter( 'excerpt_length', function () {
	return 22;
} );

// Na vista previa (Playground) a web vese como unha web normal, sen barra de administración.
add_filter( 'show_admin_bar', function ( $amosar ) {
	return file_exists( get_theme_file_path( 'VISTA-PREVIA' ) ) ? false : $amosar;
} );

/**
 * Novas que veñen de Instagram: o titular e a foto levan directamente á
 * publicación (en pestana nova) e a tarxeta non repite o texto como resumo.
 */
function iesdesar_enlace_externo( $post ) {
	$post = get_post( $post );
	return $post ? get_post_meta( $post->ID, '_iesdesar_enlace', true ) : '';
}

add_filter( 'post_link', function ( $url, $post ) {
	$externo = iesdesar_enlace_externo( $post );
	return $externo ? $externo : $url;
}, 10, 2 );

add_filter( 'get_the_excerpt', function ( $excerpt, $post ) {
	return iesdesar_enlace_externo( $post ) ? '' : $excerpt;
}, 20, 2 );

function iesdesar_nova_pestana( $html, $block, $instance ) {
	$id = isset( $instance->context['postId'] ) ? $instance->context['postId'] : get_the_ID();
	if ( ! iesdesar_enlace_externo( $id ) ) {
		return $html;
	}
	$html = preg_replace( '/(<a\b[^>]*?)\s+(?:target|rel)="[^"]*"/', '$1', $html );
	$html = preg_replace( '/(<a\b[^>]*?)\s+(?:target|rel)="[^"]*"/', '$1', $html );
	return preg_replace( '/<a\b/', '<a target="_blank" rel="noopener"', $html );
}
add_filter( 'render_block_core/post-title', 'iesdesar_nova_pestana', 10, 3 );
add_filter( 'render_block_core/post-featured-image', 'iesdesar_nova_pestana', 10, 3 );

// Sen caixa de resumo baleira nas novas de Instagram: a foto ocupa a tarxeta.
add_filter( 'render_block_core/post-excerpt', function ( $html, $block, $instance ) {
	$id = isset( $instance->context['postId'] ) ? $instance->context['postId'] : get_the_ID();
	return iesdesar_enlace_externo( $id ) ? '' : $html;
}, 10, 3 );

/**
 * Ao activar o tema por primeira vez, importa o contido traído da web antiga
 * (contido/contido.json + contido/img): páxinas, novas e fotos. Non toca nada
 * que xa exista co mesmo slug.
 */
add_action( 'after_switch_theme', 'iesdesar_contido_inicial' );

function iesdesar_contido_inicial() {
	if ( get_option( 'iesdesar_contido_creado' ) ) {
		return;
	}
	$ficheiro = get_theme_file_path( 'contido/contido.json' );
	if ( ! file_exists( $ficheiro ) ) {
		return;
	}
	$datos = json_decode( file_get_contents( $ficheiro ), true );
	if ( ! $datos ) {
		return;
	}
	// Bloqueo: se chegan dúas visitas á vez, só unha importa (evita novas dobres).
	if ( ! add_option( 'iesdesar_importando', time(), '', 'no' ) ) {
		if ( time() - (int) get_option( 'iesdesar_importando' ) < 600 ) {
			return;
		}
		update_option( 'iesdesar_importando', time() ); // Bloqueo vello dunha importación cortada.
	}
	if ( function_exists( 'set_time_limit' ) ) {
		@set_time_limit( 300 );
	}
	ignore_user_abort( true ); // Segue aínda que se peche a pestana a metade.
	if ( ! empty( $datos['lixeiro'] ) ) {
		// Versión lixeira (vista previa en Playground): sen miniaturas, carga moito máis rápido.
		add_filter( 'intermediate_image_sizes_advanced', '__return_empty_array' );
		add_filter( 'big_image_size_threshold', '__return_false' );
	}

	if ( '' === get_option( 'permalink_structure' ) ) {
		update_option( 'permalink_structure', '/%postname%/' );
		flush_rewrite_rules();
	}

	foreach ( $datos['paxinas'] as $orde => $p ) {
		$ruta = $p['pai'] ? $p['pai'] . '/' . $p['slug'] : $p['slug'];
		if ( get_page_by_path( $ruta ) ) {
			continue;
		}
		$pai = $p['pai'] ? get_page_by_path( $p['pai'] ) : null;
		wp_insert_post( array(
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_name'    => $p['slug'],
			'post_title'   => $p['titulo'],
			'post_parent'  => $pai ? $pai->ID : 0,
			'menu_order'   => $orde,
			'post_content' => iesdesar_por_ficheiros( $p['html'] ),
		) );
	}

	foreach ( $datos['novas'] as $n ) {
		$existe = get_posts( array(
			'post_type'   => 'post',
			'title'       => $n['titulo'],
			'post_status' => 'any',
			'numberposts' => 1,
		) );
		if ( $existe ) {
			continue;
		}
		$id = wp_insert_post( array(
			'post_type'    => 'post',
			'post_status'  => 'publish',
			'post_date'    => $n['data'],
			'post_title'   => $n['titulo'],
			'post_content' => iesdesar_por_ficheiros( $n['html'] ),
		) );
		if ( $id && ! is_wp_error( $id ) && ! empty( $n['enlace'] ) ) {
			update_post_meta( $id, '_iesdesar_enlace', esc_url_raw( $n['enlace'] ) );
		}
		if ( $id && ! is_wp_error( $id ) && $n['destacada'] ) {
			$adx = iesdesar_importar( 'img', $n['destacada'] );
			if ( $adx ) {
				set_post_thumbnail( $id, $adx );
			}
		}
	}

	// A entrada de exemplo de WordPress non pinta nada no carrusel.
	$ola = get_page_by_path( 'hello-world', OBJECT, 'post' );
	if ( $ola ) {
		wp_trash_post( $ola->ID );
	}

	update_option( 'iesdesar_contido_creado', 1 );
	delete_option( 'iesdesar_importando' );
}

/**
 * Cambia {{img:nome}} e {{doc:nome}} polo enderezo do ficheiro xa subido á Mediateca.
 */
function iesdesar_por_ficheiros( $html ) {
	return preg_replace_callback( '/\{\{(img|doc):([^}]+)\}\}/', function ( $m ) {
		$id = iesdesar_importar( $m[1], $m[2] );
		return $id ? esc_url( wp_get_attachment_url( $id ) ) : '#';
	}, $html );
}

/**
 * Copia unha foto (contido/img) ou documento (contido/docs) á Mediateca, unha
 * soa vez, e devolve o seu ID.
 */
function iesdesar_importar( $tipo, $nome ) {
	static $feitas = array();
	$nome = basename( $nome );
	if ( isset( $feitas[ $nome ] ) ) {
		return $feitas[ $nome ];
	}
	$orixe = get_theme_file_path( ( 'doc' === $tipo ? 'contido/docs/' : 'contido/img/' ) . $nome );
	if ( ! file_exists( $orixe ) ) {
		return $feitas[ $nome ] = 0;
	}
	$previa = get_posts( array(
		'post_type'   => 'attachment',
		'meta_key'    => '_iesdesar_orixe',
		'meta_value'  => $nome,
		'numberposts' => 1,
		'fields'      => 'ids',
	) );
	if ( $previa ) {
		return $feitas[ $nome ] = $previa[0];
	}

	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';

	$temporal = wp_tempnam( $nome );
	copy( $orixe, $temporal );
	$id = media_handle_sideload( array( 'name' => $nome, 'tmp_name' => $temporal ), 0 );
	if ( is_wp_error( $id ) ) {
		@unlink( $temporal );
		return $feitas[ $nome ] = 0;
	}
	update_post_meta( $id, '_iesdesar_orixe', $nome );
	return $feitas[ $nome ] = $id;
}
